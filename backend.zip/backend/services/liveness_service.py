import cv2
import os
import numpy as np


class LivenessService:

    def __init__(self):

        cascade_path = os.path.join(
            cv2.data.haarcascades,
            "haarcascade_frontalface_default.xml"
        )

        if not os.path.exists(cascade_path):
            raise FileNotFoundError(
                f"Cascade file not found:\n{cascade_path}"
            )

        self.face_detector = cv2.CascadeClassifier(cascade_path)

    def check(self, image_path):

        try:

            image = cv2.imread(image_path)

            if image is None:

                return {
                    "success": False,
                    "live": False,
                    "confidence": 0,
                    "status": "Image Error",
                    "message": "Unable to read image."
                }

            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

            faces = self.face_detector.detectMultiScale(
                gray,
                scaleFactor=1.1,
                minNeighbors=5,
                minSize=(80, 80)
            )

            if len(faces) == 0:

                return {
                    "success": True,
                    "live": False,
                    "confidence": 0,
                    "status": "No Face",
                    "message": "No face detected."
                }

            if len(faces) > 1:

                return {
                    "success": True,
                    "live": False,
                    "confidence": 30,
                    "status": "Multiple Faces",
                    "message": "Multiple faces detected."
                }

            brightness = np.mean(gray)

            blur = cv2.Laplacian(
                gray,
                cv2.CV_64F
            ).var()

            confidence = 100

            if blur < 100:
                confidence -= 30

            if brightness < 45:
                confidence -= 15

            if brightness > 220:
                confidence -= 15

            confidence = max(0, min(100, confidence))

            return {

                "success": True,

                "live": confidence >= 70,

                "confidence": confidence,

                "status": (
                    "Live"
                    if confidence >= 70
                    else "Suspicious"
                ),

                "blur_score": round(blur, 2),

                "brightness": round(brightness, 2),

                "message": (
                    "Live face detected."
                    if confidence >= 70
                    else "Possible spoof image."
                )

            }

        except Exception as e:

            return {

                "success": False,

                "live": False,

                "confidence": 0,

                "status": "Error",

                "message": str(e)

            }


service = LivenessService()


def check_liveness(image_path):
    return service.check(image_path)