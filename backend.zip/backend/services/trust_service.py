def calculate_trust_score(face_result, ocr_text, forgery, liveness):

    score = 0
    reasons = []

    # ---------------- Face Detection ----------------

    if face_result.get("face_detected", False):

        score += 25

        reasons.append("Face detected successfully")

    else:

        reasons.append("No face detected")

    # ---------------- Face Count ----------------

    if face_result.get("face_count", 0) == 1:

        score += 15

        reasons.append("Single face detected")

    elif face_result.get("face_count", 0) > 1:

        reasons.append("Multiple faces detected")

    # ---------------- OCR ----------------

    if ocr_text and len(ocr_text.strip()) > 20:

        score += 20

        reasons.append("Readable document extracted")

    else:

        reasons.append("Poor OCR quality")

    # ---------------- Forgery ----------------

    forgery_status = forgery.get("status", "")

    if forgery_status == "Authentic":

        score += 20

        reasons.append("Document authentic")

    elif forgery_status == "Needs Manual Review":

        score += 10

        reasons.append("Forgery requires review")

    else:

        reasons.append("Forgery suspected")

    # ---------------- Liveness ----------------

    live = liveness.get("live", False)

    confidence = liveness.get("confidence", 0)

    if live:

        score += 20

        reasons.append("Live face detected")

    elif confidence >= 50:

        score += 10

        reasons.append("Liveness requires manual review")

    else:

        reasons.append("Possible spoof attempt")

    # ---------------- Final Score ----------------

    score = max(0, min(100, score))

    if score >= 85:

        status = "Verified"

        risk = "Low"

    elif score >= 60:

        status = "Needs Review"

        risk = "Medium"

    else:

        status = "Rejected"

        risk = "High"

    return {

        "trust_score": score,

        "status": status,

        "risk_level": risk,

        "reasons": reasons,

        "face": face_result,

        "forgery": forgery,

        "liveness": liveness

    }