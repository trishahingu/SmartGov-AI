import os
import re
import cv2
import easyocr
import numpy as np

try:
    from pdf2image import convert_from_path
    PDF_SUPPORT = True
except:
    PDF_SUPPORT = False

reader = easyocr.Reader(['en'], gpu=False)


def load_image(file_path):

    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".pdf":

        if not PDF_SUPPORT:
            raise Exception("pdf2image not installed.")

        pages = convert_from_path(file_path, dpi=300)

        image = np.array(pages[0])

        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

        return image

    image = cv2.imread(file_path)

    if image is None:
        raise Exception("Unable to read image.")

    return image


def extract_text(file_path):
    """
    Old function kept for compatibility.
    Returns plain OCR text.
    """

    image = load_image(file_path)

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    result = reader.readtext(gray)

    text = ""

    for r in result:
        text += r[1] + "\n"

    return text.strip()


def detect_document_type(text):

    t = text.upper()

    if "AADHAAR" in t or "UIDAI" in t:
        return "Aadhaar Card"

    if "PAN" in t:
        return "PAN Card"

    if "PASSPORT" in t:
        return "Passport"

    if "DRIVING" in t:
        return "Driving Licence"

    return "Unknown"


def extract_document_data(file_path):
    """
    New function for structured OCR.
    """

    text = extract_text(file_path)

    aadhaar = "--"

    match = re.search(r"\d{4}\s\d{4}\s\d{4}", text)

    if match:
        aadhaar = match.group()

    dob = "--"

    match = re.search(r"\d{2}/\d{2}/\d{4}", text)

    if match:
        dob = match.group()

    gender = "--"

    if "MALE" in text.upper():
        gender = "Male"

    if "FEMALE" in text.upper():
        gender = "Female"

    name = "--"

    lines = text.split("\n")

    ignore = [
        "INDIA",
        "GOVERNMENT",
        "AADHAAR",
        "DOB",
        "MALE",
        "FEMALE"
    ]

    for line in lines:

        l = line.strip()

        if len(l) < 3:
            continue

        if any(i in l.upper() for i in ignore):
            continue

        if any(c.isdigit() for c in l):
            continue

        name = l.title()

        break

    return {

        "success": True,

        "document_type": detect_document_type(text),

        "citizen_name": name,

        "aadhaar_number": aadhaar,

        "dob": dob,

        "gender": gender,

        "ocr_text": text

    }